Mark Glinberg
mglinberg3
903685285

Welcome to my adaptation of the World's Hardest Game!

You control the GT player sprite with the arrow keys, and your goal is to reach the other
green side of the stage without touching any of the enemies.

If you touch an enemy, the level will reset, and you will get to try again.

The game counts the amount of times you fail, and you can always exit to the main menu
by pressing SELECT (backspace).

If you exit to the main menu while playing the game, the number of fails does not reset 
(on purpose). The only way to reset the number of times you failed is to beat the game :D.