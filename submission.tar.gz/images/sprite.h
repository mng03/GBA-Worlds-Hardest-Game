/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=8x8 sprite sprite.png 
 * Time-stamp: Monday 04/04/2022, 02:57:54
 * 
 * Image Information
 * -----------------
 * sprite.png 8@8
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPRITE_H
#define SPRITE_H

extern const unsigned short sprite[64];
#define SPRITE_SIZE 128
#define SPRITE_LENGTH 64
#define SPRITE_WIDTH 8
#define SPRITE_HEIGHT 8

#endif

